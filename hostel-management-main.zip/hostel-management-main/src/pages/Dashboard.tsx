import { Users, DoorOpen, CreditCard, MessageSquareWarning, ClipboardCheck, Building2 } from "lucide-react";
import StatCard from "@/components/StatCard";
import { mockStudents, mockRooms, mockComplaints, mockFees } from "@/data/mockData";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const Dashboard = () => {
  const totalStudents = mockStudents.length;
  const totalRooms = mockRooms.length;
  const availableRooms = mockRooms.filter((r) => r.status === "available").length;
  const pendingFees = mockFees.filter((f) => f.status !== "paid").length;
  const pendingComplaints = mockComplaints.filter((c) => c.status === "pending").length;
  const occupancyRate = Math.round(
    (mockRooms.reduce((sum, r) => sum + r.occupants, 0) /
      mockRooms.reduce((sum, r) => sum + r.capacity, 0)) *
      100
  );

  const roomTypeData = [
    { name: "Single", count: mockRooms.filter((r) => r.type === "single").length },
    { name: "Double", count: mockRooms.filter((r) => r.type === "double").length },
    { name: "Triple", count: mockRooms.filter((r) => r.type === "triple").length },
  ];

  const feeStatusData = [
    { name: "Paid", value: mockFees.filter((f) => f.status === "paid").length },
    { name: "Pending", value: mockFees.filter((f) => f.status === "pending").length },
    { name: "Overdue", value: mockFees.filter((f) => f.status === "overdue").length },
  ];

  const PIE_COLORS = ["hsl(142, 60%, 40%)", "hsl(38, 92%, 50%)", "hsl(0, 72%, 51%)"];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">Overview of hostel operations</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard title="Total Students" value={totalStudents} icon={Users} variant="accent" />
        <StatCard title="Total Rooms" value={totalRooms} icon={DoorOpen} variant="default" />
        <StatCard title="Available Rooms" value={availableRooms} icon={Building2} variant="success" />
        <StatCard title="Occupancy Rate" value={`${occupancyRate}%`} icon={ClipboardCheck} variant="accent" />
        <StatCard title="Pending Fees" value={pendingFees} icon={CreditCard} variant="warning" />
        <StatCard title="Complaints" value={pendingComplaints} icon={MessageSquareWarning} variant="destructive" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-lg border border-border bg-card p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Rooms by Type</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={roomTypeData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214, 20%, 88%)" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="hsl(174, 55%, 40%)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-lg border border-border bg-card p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Fee Collection Status</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={feeStatusData} cx="50%" cy="50%" outerRadius={90} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                {feeStatusData.map((_, index) => (
                  <Cell key={index} fill={PIE_COLORS[index]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
