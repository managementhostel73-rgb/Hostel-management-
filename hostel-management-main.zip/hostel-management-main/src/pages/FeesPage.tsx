import { useState } from "react";
import { mockFees } from "@/data/mockData";
import { FeeRecord } from "@/types/hostel";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const statusBadge = {
  paid: "bg-success/10 text-success",
  pending: "bg-warning/10 text-warning",
  overdue: "bg-destructive/10 text-destructive",
};

const FeesPage = () => {
  const [fees, setFees] = useState<FeeRecord[]>(mockFees);

  const markPaid = (id: string) => {
    setFees(fees.map((f) => f.id === id ? { ...f, status: "paid" as const, paidDate: new Date().toISOString().split("T")[0] } : f));
    toast.success("Fee marked as paid");
  };

  const totalCollected = fees.filter((f) => f.status === "paid").reduce((sum, f) => sum + f.amount, 0);
  const totalPending = fees.filter((f) => f.status !== "paid").reduce((sum, f) => sum + f.amount, 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Fee Management</h1>
        <p className="text-sm text-muted-foreground mt-1">Track and manage hostel fees</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-lg border border-border bg-card p-4">
          <p className="text-sm text-muted-foreground">Total Collected</p>
          <p className="text-xl font-bold text-success">₹{totalCollected.toLocaleString()}</p>
        </div>
        <div className="rounded-lg border border-border bg-card p-4">
          <p className="text-sm text-muted-foreground">Pending Amount</p>
          <p className="text-xl font-bold text-warning">₹{totalPending.toLocaleString()}</p>
        </div>
        <div className="rounded-lg border border-border bg-card p-4">
          <p className="text-sm text-muted-foreground">Collection Rate</p>
          <p className="text-xl font-bold text-foreground">{Math.round((totalCollected / (totalCollected + totalPending)) * 100)}%</p>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/50">
              <th className="text-left p-3 font-medium text-muted-foreground">Student</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Amount</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Due Date</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Status</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {fees.map((f) => (
              <tr key={f.id} className="border-b border-border last:border-0 hover:bg-muted/30">
                <td className="p-3 font-medium text-foreground">{f.studentName}</td>
                <td className="p-3 text-muted-foreground">₹{f.amount.toLocaleString()}</td>
                <td className="p-3 text-muted-foreground">{f.dueDate}</td>
                <td className="p-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium capitalize ${statusBadge[f.status]}`}>{f.status}</span>
                </td>
                <td className="p-3">
                  {f.status !== "paid" && <Button size="sm" onClick={() => markPaid(f.id)}>Mark Paid</Button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default FeesPage;
