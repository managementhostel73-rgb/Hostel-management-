import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  DoorOpen,
  CreditCard,
  MessageSquareWarning,
  ClipboardCheck,
  FileBarChart,
  Building2,
} from "lucide-react";

const navItems = [
  { label: "Dashboard", icon: LayoutDashboard, path: "/" },
  { label: "Students", icon: Users, path: "/students" },
  { label: "Rooms", icon: DoorOpen, path: "/rooms" },
  { label: "Allocation", icon: Building2, path: "/allocation" },
  { label: "Fees", icon: CreditCard, path: "/fees" },
  { label: "Complaints", icon: MessageSquareWarning, path: "/complaints" },
  { label: "Attendance", icon: ClipboardCheck, path: "/attendance" },
  { label: "Reports", icon: FileBarChart, path: "/reports" },
];

const AppSidebar = () => {
  const location = useLocation();

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 bg-sidebar text-sidebar-foreground flex flex-col">
      <div className="flex items-center gap-3 px-6 py-5 border-b border-sidebar-border">
        <Building2 className="h-7 w-7 text-sidebar-primary" />
        <span className="text-lg font-bold tracking-tight text-sidebar-primary-foreground">
          HostelHub
        </span>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-primary"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              }`}
            >
              <item.icon className="h-4.5 w-4.5" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="px-6 py-4 border-t border-sidebar-border text-xs text-sidebar-foreground/60">
        © 2026 HostelHub
      </div>
    </aside>
  );
};

export default AppSidebar;
